//Race
//Andrew Book
//CS 165
//Apr 16, 2020
//andrew@bookfamily.com

package packets;

public abstract class Packet {
	public Packet() {
		
	}
	
	public abstract byte[] getData();
	
	public static String readData(byte[] data) {
		String message = new String(data).trim();
		return message.substring(1);
	}
}
