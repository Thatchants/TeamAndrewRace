//Race
//Andrew Book
//CS 165
//Apr 17, 2020
//andrew@bookfamily.com

package packets;

public class PacketObstacle extends Packet{

	@Override
	public byte[] getData() {
		return ("3").getBytes();
	}

}
